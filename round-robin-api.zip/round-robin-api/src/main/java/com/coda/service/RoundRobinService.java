package com.coda.service;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cglib.core.internal.LoadingCache;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.coda.entity.Game;
import com.google.common.cache.CacheLoader;

@Service("roundRobinService")
@Scope
public class RoundRobinService {

	@Value("${application.additional.ports}")
	private String additionalPorts;
	
	@Value("${application.host}")
	private String host;
	
	@Value("${application.api.name}")
	private String apiName;
	
	private static LinkedHashSet<String> listofPorts;
	
	
	
	@PostConstruct
	public void setAllPorts() {
		System.out.println("ADditional "+additionalPorts);
			listofPorts = new LinkedHashSet<>(Arrays.asList(additionalPorts.split(",")));
	}
	
	public String getPortToRun() {
		if(listofPorts == null || listofPorts.isEmpty() ) {
			setAllPorts();
		}
		 int random = new Random().nextInt(listofPorts.size());
	    Object arr[]= listofPorts.toArray();
	    return arr[random].toString();
	}
	
	public void addHost(String host) {
		listofPorts.add(host);
	}
	
	public void rempve(String host) {
		listofPorts.remove(host);
	}
	
	public LinkedHashSet<String> getPorts() {
		return listofPorts;
	}
	public ResponseEntity<Game> executeTask(Game game) {
		String  port = getPortToRun();
		String uri = "http://"+host + ":" +port+"/"+apiName;
		RestTemplate template = new RestTemplate();
		ResponseEntity<Game> games = null;
		long startTime = System.currentTimeMillis();
		try {
			games = template.postForEntity(uri, game, Game.class);
		}catch (Exception e) {
			listofPorts.remove(port);
		}
		if(games.getStatusCode()!=HttpStatus.OK || (System.currentTimeMillis()-startTime>120000)) {
			listofPorts.remove(port);
			return games;
		}else {
			return games;
		}
		
	}
}
