package com.coda.scheduler;

import java.util.LinkedHashSet;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.coda.entity.Game;
import com.coda.service.RoundRobinService;

@Component
public class ApiChecker {

	@Value("${application.host}")
	private String host;
	
	@Value("${application.heartbeat.api.name}")
	private String apiName;
	
	@Autowired
	RoundRobinService roundRobinService;
	
	@Scheduled(timeUnit = TimeUnit.SECONDS, fixedDelay = 30, initialDelay = 30)
	public void isapirunning() {
		LinkedHashSet<String> listofPorts = roundRobinService.getPorts();
		String  port = roundRobinService.getPortToRun();
		String uri = "http://"+host + ":" +port+"/"+apiName;
		System.out.println("REQUEST SENT ON "+uri);
		HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
		httpRequestFactory.setConnectTimeout(60*1000*2);
		httpRequestFactory.setReadTimeout(60*1000*2);
		RestTemplate template = new RestTemplate(httpRequestFactory);
		ResponseEntity<String> response = null;
		try {
			 response= template.getForEntity(uri, String.class);
		}catch(Exception e){
			listofPorts.remove(port);
			System.out.println("API REMOVED PORT : "+port);
		}
		if(response!= null) {
			if(response.getStatusCode()!=HttpStatus.OK) {
				System.out.println("API REMOVED PORT : "+port);
				listofPorts.remove(port);
			}else {
				if(!listofPorts.contains(port)) {
					System.out.println("API ADDED PORT : "+port);
					roundRobinService.addHost(port);
				}
			}
		}
		System.out.println("API  PORTs : "+roundRobinService.getPorts());
	
	}
	
	@Scheduled(timeUnit = TimeUnit.MINUTES, fixedDelay = 3, initialDelay = 1 )
	public void resetPorts() {
		roundRobinService.getPorts().clear();
		System.out.println("Ports invalidated" );
		
	}
	
}
