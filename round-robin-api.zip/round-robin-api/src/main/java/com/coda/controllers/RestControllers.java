package com.coda.controllers;

import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.coda.entity.Game;
import com.coda.service.RoundRobinService;

@RestController
@RequestMapping(value = "application")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public class RestControllers {

	@Autowired
	RoundRobinService roundRobinService;
	@PostMapping("/getgame")
	public ResponseEntity<Game> roundRobinAPI(@Valid @RequestBody Game game) {
		return roundRobinService.executeTask(game);
	}
	
}
